using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blocks : MonoBehaviour
{
    AudioSource audioPlayer;
    Rigidbody2D rb;
    bool hit;
    // Start is called before the first frame update
    void Start()
    {
        audioPlayer = GetComponent<AudioSource>();
        rb = GetComponent<Rigidbody2D>();
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        float power = rb.velocity.magnitude;
        if (power > 3 && (hit == false))
        {
            audioPlayer.Play();
            hit = true;
        }
        if (power < 1 && hit)
        {
            audioPlayer.Play();
            hit = false;
        }
    }
}