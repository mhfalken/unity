using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Slingshot : MonoBehaviour
{
    [SerializeField] LineRenderer[] lineRenderers;
    [SerializeField] Transform[] stripPositions;
    [SerializeField] Transform center;
    [SerializeField] Transform idlePosition;
    [SerializeField] GameObject[] ballPrefab;
    [SerializeField] float maxLength;
    [SerializeField] float bottomBoundary;
    [SerializeField] float rightBoundary;
    [SerializeField] float ballPositionOffset;
    [SerializeField] float force;

    Rigidbody2D ball;
    Collider2D ballCollider;
    Vector3 currentPosition;
    bool isMouseDown;
    int nextBall;
    int ballCnt;

    void Start()
    {
        lineRenderers[0].positionCount = 2;
        lineRenderers[1].positionCount = 2;
        lineRenderers[0].SetPosition(0, stripPositions[0].position);
        lineRenderers[1].SetPosition(0, stripPositions[1].position);

        Createball();
    }

    void NextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    void Createball()
    {
        if (ballCnt == 3)
            Invoke("NextLevel", 0);
        ballCnt++;
        ball = Instantiate(ballPrefab[nextBall]).GetComponent<Rigidbody2D>();
        if (++nextBall == ballPrefab.Length)
            nextBall = 0;
        ballCollider = ball.GetComponent<Collider2D>();
        ballCollider.enabled = false;

        ball.isKinematic = true;

        ResetStrips();
        if (ballCnt == 3)
            Invoke("NextLevel", 0);
        if (!GameObject.FindGameObjectWithTag("Coin"))
        {
            Invoke("NextLevel", 2);
        }
        ballCnt++;
    }

    void Update()
    {
        if (isMouseDown)
        {
            Vector3 mousePosition = Input.mousePosition;
            mousePosition.z = 10;

            currentPosition = Camera.main.ScreenToWorldPoint(mousePosition);
            currentPosition = center.position + Vector3.ClampMagnitude(currentPosition
                - center.position, maxLength);

            currentPosition = ClampBoundary(currentPosition);

            SetStrips(currentPosition);

            if (ballCollider)
            {
                ballCollider.enabled = true;
            }
        }
        else
        {
            ResetStrips();
        }
    }

    private void OnMouseDown()
    {
        isMouseDown = true;
    }

    private void OnMouseUp()
    {
        isMouseDown = false;
        Shoot();
        currentPosition = idlePosition.position;
    }

    void Shoot()
    {
        ball.isKinematic = false;
        Vector3 ballForce = (currentPosition - center.position) * force * -1;
        ball.velocity = ballForce;

        //ball.GetComponent<ball>().Release();

        ball = null;
        ballCollider = null;
        Invoke("Createball", 3);
    }

    void ResetStrips()
    {
        currentPosition = idlePosition.position;
        SetStrips(currentPosition);
    }

    void SetStrips(Vector3 position)
    {
        lineRenderers[0].SetPosition(1, position);
        lineRenderers[1].SetPosition(1, position);

        if (ball)
        {
            Vector3 dir = position - center.position;
            ball.transform.position = position + dir.normalized * ballPositionOffset;
            ball.transform.right = -dir.normalized;
        }
    }

    Vector3 ClampBoundary(Vector3 vector)
    {
        vector.y = Mathf.Clamp(vector.y, bottomBoundary, 1000);
        vector.x = Mathf.Clamp(vector.x, -50, rightBoundary);
        return vector;
    }
}