using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Basketball : MonoBehaviour
{
    [SerializeField] Text score;
    [SerializeField] Text tid;
    [SerializeField] AudioClip scoreSound;
    [SerializeField] AudioClip endSound;

    AudioSource audioPlayer;
    Vector3 startOfMovement;
    Vector3 originalPosition;
    int point;
    float timeLeft = 60;
    bool timeEnd;

    private void Start()
    {
        originalPosition = transform.position;
        audioPlayer = GetComponent<AudioSource>();
    }

    private void Update()
    {
        timeLeft -= Time.deltaTime;
        if (timeLeft < 0)
        {
            timeLeft = 0;
            if (timeEnd == false)
            {
                timeEnd = true;
                audioPlayer.PlayOneShot(endSound, 1.0f);
            }
        }
        tid.text = "Tid: " + timeLeft.ToString("00");
    }

    private void OnMouseDown()
    {
        startOfMovement = Input.mousePosition;
    }

    private void OnMouseUp()
    {
        Vector2 movement = Input.mousePosition - startOfMovement;
        GetComponent<Rigidbody2D>().AddForce(movement / 20.0f, ForceMode2D.Impulse);
    }
    private void Reset()
    {
        GetComponent<Rigidbody2D>().velocity = Vector2.zero;
        GetComponent<Rigidbody2D>().angularVelocity = 0.0f;
        transform.position = originalPosition;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Reset")
        {
            Reset();
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "KurvHit")
        {
            point++;
            score.text = "Score: " + point;
            audioPlayer.PlayOneShot(scoreSound, 1.0f);
        }
    }
}
