using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    [SerializeField] float speed = 10;
    [SerializeField] float jumpPower = 200;
    [SerializeField] LayerMask groundLayer;
    [SerializeField] AudioClip jumpSound;
    [SerializeField] AudioClip itemSound;
    [SerializeField] AudioClip deadSound;
    [SerializeField] Text score;
    SpriteRenderer sr;
    Rigidbody2D rb;
    BoxCollider2D bc;
    Animator animator;
    AudioSource audioPlayer;
    int point;


    // Start is called before the first frame update
    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        bc = GetComponent<BoxCollider2D>();
        animator = GetComponent<Animator>();
        audioPlayer = GetComponent<AudioSource>();
        point = PlayerPrefs.GetInt("Score");
    }

    // Update is called once per frame
    void Update()
    {
        float dir = Input.GetAxisRaw("Horizontal");
        bool jump = Input.GetButtonDown("Jump");

        transform.Translate(dir * speed * Time.deltaTime, 0, 0);
        if (dir < 0)
            sr.flipX = true;
        if (dir > 0)
            sr.flipX = false;
        if (dir == 0)
            animator.SetBool("Run", false);
        else 
            animator.SetBool("Run", true);
        if (jump && GroundCheck())
        {
            rb.AddForce(Vector3.up * jumpPower);
            audioPlayer.PlayOneShot(jumpSound, 1);
        }
        score.text = "Score: " + point;
    }

    bool GroundCheck()
    {
        return Physics2D.CapsuleCast(bc.bounds.center, bc.bounds.size, 0f, 0f, Vector2.down, 0.5f, groundLayer);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Fruit"))
        {
            Animator animC = collision.gameObject.GetComponent<Animator>();
            animC.SetTrigger("Taken");
            //Destroy(collision.gameObject);
            audioPlayer.PlayOneShot(itemSound, 1);
            point += 10;    // Alle give 10 point
            if (collision.gameObject.name == "Orange")
                point += 10;  // Nogle giver ekstra
            if (collision.gameObject.name == "Bananas")
                point += 20;  // Nogle giver ekstra
            if (collision.gameObject.name == "Strawberry")
                point += 30;  // Nogle giver ekstra
            PlayerPrefs.SetInt("Score", point);
        }

        if (collision.gameObject.CompareTag("Trap"))
        {
            audioPlayer.PlayOneShot(deadSound, 1);
            //Destroy(gameObject, 1);
            animator.SetTrigger("Die");
            Invoke("RestartLevel", 2);
        }

    }

    private void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
